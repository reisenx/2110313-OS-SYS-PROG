#!/bin/bash
java -mx64m -cp "lib/*" PS
