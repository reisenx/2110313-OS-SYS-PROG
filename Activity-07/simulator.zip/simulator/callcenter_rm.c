#include <stdio.h>
#include <semaphore.h>

void main() {
    int r = sem_unlink("callcenter");
}

